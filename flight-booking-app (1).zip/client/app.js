fetch("http://localhost:4000/api/flights")
  .then(res => res.json())
  .then(flights => {
    const container = document.getElementById("flights");
    if (flights.length === 0) {
      container.innerHTML = "<p>No flights available.</p>";
      return;
    }
    flights.forEach(flight => {
      const div = document.createElement("div");
      div.innerHTML = `
        <h3>${flight.from} → ${flight.to}</h3>
        <p><strong>${new Date(flight.departureTime).toLocaleString()}</strong></p>
        <p>Price: KES ${flight.price}</p>
        <a href="booking.html?flightId=${flight._id}">Book this flight</a>
        <hr>
      `;
      container.appendChild(div);
    });
  });
