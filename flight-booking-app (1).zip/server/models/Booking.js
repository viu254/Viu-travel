const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  flightId: { type: mongoose.Schema.Types.ObjectId, ref: 'Flight' },
  passengerName: String,
  passportNumber: String,
  email: String,
  mpesaCode: String,
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Booking', bookingSchema);
