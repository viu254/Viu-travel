const mongoose = require('mongoose');

const flightSchema = new mongoose.Schema({
  flightNumber: String,
  from: String,
  to: String,
  departureTime: Date,
  arrivalTime: Date,
  price: Number,
  seatsAvailable: Number,
});

module.exports = mongoose.model('Flight', flightSchema);
