const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');

// Create booking
router.post('/', async (req, res) => {
  const booking = new Booking(req.body);
  await booking.save();
  res.status(201).json({ message: 'Booking submitted. M-Pesa code will be verified.', booking });
});

// Get booking
router.get('/:id', async (req, res) => {
  const booking = await Booking.findById(req.params.id).populate('flightId');
  res.json(booking);
});

module.exports = router;
