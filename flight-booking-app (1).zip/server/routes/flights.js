const express = require('express');
const router = express.Router();
const Flight = require('../models/Flight');

// Get all flights
router.get('/', async (req, res) => {
  const flights = await Flight.find();
  res.json(flights);
});

// Admin: Add a flight
router.post('/', async (req, res) => {
  const flight = new Flight(req.body);
  await flight.save();
  res.status(201).json(flight);
});

module.exports = router;
